package MyPack.HospitalManagmentBackEnd.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import MyPack.HospitalManagmentBackEnd.Entity.Nurse;
import MyPack.HospitalManagmentBackEnd.Service.NurseService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/nurses")
@CrossOrigin("*")
public class NurseController {

    @Autowired
    private NurseService nurseService;

    @GetMapping("/getAllNurse")
    public List<Nurse> getAllNurses() {
        return nurseService.getAllNurses();
    }

    @GetMapping("/{id}")
    public Nurse getNurseById(@PathVariable Long id) {
        return nurseService.getNurseById(id);
    }

    @PostMapping("/postNurse")
    public Nurse addNurse(@RequestBody Nurse nurse) {
        return nurseService.saveNurse(nurse);
    }

    @PutMapping("/putNurse/{id}")
    public Nurse updateNurse(@PathVariable Long id, @RequestBody Nurse nurse) {
        return nurseService.updateNurse(id, nurse);
    }

    @DeleteMapping("/{id}")
    public void deleteNurse(@PathVariable Long id) {
        nurseService.deleteNurse(id);
    }
}
