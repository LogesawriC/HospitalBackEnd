package MyPack.HospitalManagmentBackEnd.Entity;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class DiagnosticReport
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Add properties related to the diagnostic report
    private String description;
    
    private String patientName;
    private LocalDate date;
    private String doctorName;
    
    

	public Long getId() 
	{
		return id;
	}

	public void setId(Long id)
	{
		this.id = id;
	}

	public String getDescription() 
	{
		return description;
	}

	public void setDescription(String description)
	{
		this.description = description;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public String getDoctorName() {
		return doctorName;
	}

	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}

	public DiagnosticReport(Long id, String description, String patientName, LocalDate date, String doctorName) {
		super();
		this.id = id;
		this.description = description;
		this.patientName = patientName;
		this.date = date;
		this.doctorName = doctorName;
	}

	public DiagnosticReport() {
		super();
		// TODO Auto-generated constructor stub
	}


	
	
}

