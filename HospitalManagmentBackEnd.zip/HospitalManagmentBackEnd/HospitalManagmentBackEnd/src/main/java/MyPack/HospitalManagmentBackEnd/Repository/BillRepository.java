package MyPack.HospitalManagmentBackEnd.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import MyPack.HospitalManagmentBackEnd.Entity.Bill;

@Repository
public interface BillRepository extends JpaRepository<Bill, Long> 
{
	public Bill findById(long id);
	public Bill deleteById(long id);
	
}
