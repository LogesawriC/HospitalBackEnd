package MyPack.HospitalManagmentBackEnd.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import MyPack.HospitalManagmentBackEnd.Entity.LabTest;

public interface LabTestRepository extends JpaRepository<LabTest, Long>
{
	public LabTest findById(long id);
	public LabTest deleteById(long id);
	public LabTest findByTestname(String testname);
	
}