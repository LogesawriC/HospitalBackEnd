package MyPack.HospitalManagmentBackEnd.Service;

import java.util.List;

import MyPack.HospitalManagmentBackEnd.Entity.Accountant;

import java.util.List;

import java.util.List;

public interface AccountantService {
    List<Accountant> getAllAccountants();
    Accountant getAccountantById(Long id);
    Accountant saveAccountant(Accountant accountant);
    Accountant updateAccountant(Long id, Accountant accountant);
    void deleteAccountant(Long id);
}
