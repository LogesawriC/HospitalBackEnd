package MyPack.HospitalManagmentBackEnd.Service;

import java.util.List;

import MyPack.HospitalManagmentBackEnd.Entity.Bill;

public interface BillService 
{

	public Bill createBill(Bill bill);
	
	public void deleteBill(Long id);
			
	public Bill updateBill(Bill bill);
			
	public Bill getBill(Long id);

	public List<Bill> getAllBills();
	

}
