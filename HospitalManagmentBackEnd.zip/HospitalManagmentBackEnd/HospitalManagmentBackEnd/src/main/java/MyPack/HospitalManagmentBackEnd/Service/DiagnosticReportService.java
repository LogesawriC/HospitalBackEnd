package MyPack.HospitalManagmentBackEnd.Service;

import java.util.List;

import MyPack.HospitalManagmentBackEnd.Entity.DiagnosticReport;

public interface DiagnosticReportService {
	
    List<DiagnosticReport> getAllDiagnosticReports();
    
    DiagnosticReport getDiagnosticReportById(Long id);
    
    DiagnosticReport saveDiagnosticReport(DiagnosticReport report);
    
    DiagnosticReport updateDiagnosticReport(Long id, DiagnosticReport report);
    
    void deleteDiagnosticReport(Long id);
}