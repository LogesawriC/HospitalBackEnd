package MyPack.HospitalManagmentBackEnd.Service;

import java.util.List;

import org.springframework.stereotype.Service;

import MyPack.HospitalManagmentBackEnd.Entity.Doctor;
import MyPack.HospitalManagmentBackEnd.Repository.DoctorRepository;
import jakarta.transaction.Transactional;


public interface DoctorService {
	
    List<Doctor> getAllDoctors();
    
    Doctor getDoctorById(Long id);
    
    Doctor saveDoctor(Doctor doctor);
    
    Doctor updateDoctor(Long id, Doctor doctor);
    
    void deleteDoctor(Long id);
}
