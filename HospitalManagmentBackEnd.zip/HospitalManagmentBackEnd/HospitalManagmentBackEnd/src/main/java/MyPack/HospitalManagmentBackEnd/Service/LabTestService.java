package MyPack.HospitalManagmentBackEnd.Service;

import java.util.List;

import MyPack.HospitalManagmentBackEnd.Entity.LabTest;

public interface LabTestService
{		
	public LabTest createLabTest(LabTest labTest);
	public void deleteLabTest(Long id);
	public LabTest updateLabTest(LabTest labTest);
	public LabTest getLabTest(String testname);
	public List<LabTest> getAllLabTests();

}
