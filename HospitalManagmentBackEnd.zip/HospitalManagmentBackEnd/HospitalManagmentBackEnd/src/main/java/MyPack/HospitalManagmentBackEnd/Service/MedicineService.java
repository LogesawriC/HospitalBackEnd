package MyPack.HospitalManagmentBackEnd.Service;

import java.util.List;

import MyPack.HospitalManagmentBackEnd.Entity.Medicine;

import java.util.List;

public interface MedicineService {
    List<Medicine> getAllMedicines();
    Medicine getMedicineById(Long id);
    Medicine saveMedicine(Medicine medicine);
    Medicine updateMedicine(Long id, Medicine medicine);
    void deleteMedicine(Long id);
}
