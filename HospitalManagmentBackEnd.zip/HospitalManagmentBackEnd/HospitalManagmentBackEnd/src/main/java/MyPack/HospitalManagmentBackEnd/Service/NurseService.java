package MyPack.HospitalManagmentBackEnd.Service;

import java.util.List;

import MyPack.HospitalManagmentBackEnd.Entity.Nurse;

import java.util.List;

public interface NurseService {
    List<Nurse> getAllNurses();
    
    Nurse getNurseById(Long id);
    
    Nurse saveNurse(Nurse nurse);
    
    Nurse updateNurse(Long id, Nurse nurse);
    
    void deleteNurse(Long id);
}
