package MyPack.HospitalManagmentBackEnd.Service;

import java.util.List;

import MyPack.HospitalManagmentBackEnd.Entity.Patient;

public interface PatientService {
    Patient createPatient(Patient patient);
    Patient updatePatient(Patient patient);
    void deletePatient(Long id);
    Patient getPatientById(Long id);
    List<Patient> getAllPatients();
}

