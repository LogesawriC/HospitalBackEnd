package MyPack.HospitalManagmentBackEnd.Service;

import java.util.List;

import MyPack.HospitalManagmentBackEnd.Entity.Prescription;

import java.util.List;

public interface PrescriptionService {
    List<Prescription> getAllPrescriptions();
    Prescription getPrescriptionById(Long id);
    Prescription savePrescription(Prescription prescription);
    Prescription updatePrescription(Long id, Prescription prescription);
    void deletePrescription(Long id);
}
