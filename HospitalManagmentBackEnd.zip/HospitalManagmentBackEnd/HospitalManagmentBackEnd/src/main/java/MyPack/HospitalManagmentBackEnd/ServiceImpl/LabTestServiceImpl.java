package MyPack.HospitalManagmentBackEnd.ServiceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import MyPack.HospitalManagmentBackEnd.Entity.LabTest;
import MyPack.HospitalManagmentBackEnd.Repository.LabTestRepository;
import MyPack.HospitalManagmentBackEnd.Service.LabTestService;

@Service
public class LabTestServiceImpl implements LabTestService
{
	@Autowired
	private LabTestRepository labtestRepository;

	@Override
	public LabTest createLabTest(LabTest labTest)
	{
		return this.labtestRepository.save(labTest);
	}

	@Override
	public void deleteLabTest(Long id)
	{
		this.labtestRepository.deleteById(id);		
	}

	@Override
	public LabTest updateLabTest(LabTest labTest) 
	{
		return this.labtestRepository.save(labTest);
	}

	@Override
	public LabTest getLabTest(String testname) 
	{
		return this.labtestRepository.findByTestname(testname);
	}

	@Override
	public List<LabTest> getAllLabTests() {
		// TODO Auto-generated method stub
		return this.labtestRepository.findAll();
	}
}
