package MyPack.HospitalManagmentBackEnd.ServiceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import MyPack.HospitalManagmentBackEnd.Entity.Nurse;
import MyPack.HospitalManagmentBackEnd.Repository.NurseRepository;
import MyPack.HospitalManagmentBackEnd.Service.NurseService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class NurseServiceImpl implements NurseService {

    @Autowired
    private NurseRepository nurseRepository;

    @Override
    public List<Nurse> getAllNurses() {
        return nurseRepository.findAll();
    }

    @Override
    public Nurse getNurseById(Long id) {
        return nurseRepository.findById(id).orElse(null);
    }

    @Override
    public Nurse saveNurse(Nurse nurse) {
        return nurseRepository.save(nurse);
    }

    @Override
    public Nurse updateNurse(Long id, Nurse nurse) {
        Optional<Nurse> existingNurse = nurseRepository.findById(id);
        if (existingNurse.isPresent()) {
            nurse.setId(id);
            return nurseRepository.save(nurse);
        }
        return null;
    }

    @Override
    public void deleteNurse(Long id) {
        nurseRepository.deleteById(id);
    }
}
