package MyPack.HospitalManagmentBackEnd.ServiceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import MyPack.HospitalManagmentBackEnd.Entity.Patient;
import MyPack.HospitalManagmentBackEnd.Repository.PatientRepository;
import MyPack.HospitalManagmentBackEnd.Service.PatientService;
import jakarta.transaction.Transactional;

@Service
@Transactional
public class PatientServiceimpl implements PatientService {

    @Autowired
    private PatientRepository patientRepository;

    @Override
    public Patient createPatient(Patient patient) {
        return patientRepository.save(patient);
    }

    @Override
    public Patient updatePatient(Patient patient) {
        return patientRepository.save(patient);
    }

    @Override
    public void deletePatient(Long id) {
        patientRepository.deleteById(id);
    }

    @Override
    public Patient getPatientById(Long id) {
        return patientRepository.findById(id).orElse(null);
    }

    @Override
    public List<Patient> getAllPatients() {
        return patientRepository.findAll();
    }
}

